-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 24 Okt 2019 pada 18.53
-- Versi Server: 10.1.19-MariaDB
-- PHP Version: 7.0.13

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sihh`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `departement`
--

CREATE TABLE `departement` (
  `kode_departement` varchar(5) NOT NULL,
  `nama_departement` varchar(25) NOT NULL,
  `keterangan` tinytext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `departement`
--

INSERT INTO `departement` (`kode_departement`, `nama_departement`, `keterangan`) VALUES
('E', 'Enginer', 'Khusus Perbaikan'),
('FO', 'Front Office', 'Lolos'),
('HK', 'House Keeping', 'terbanyak'),
('ITO', 'IT Office', 'It'),
('KTC', 'Kitchen', 'Masak'),
('O', 'Office', 'Kantor');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pegawai`
--

CREATE TABLE `pegawai` (
  `nip` varchar(8) NOT NULL,
  `nama_pegawai` varchar(25) NOT NULL,
  `kode_departement` varchar(5) NOT NULL,
  `jabatan` varchar(15) NOT NULL,
  `email` varchar(32) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `foto` varchar(32) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pegawai`
--

INSERT INTO `pegawai` (`nip`, `nama_pegawai`, `kode_departement`, `jabatan`, `email`, `tanggal_lahir`, `foto`) VALUES
('E1', 'Fathur Firmansyah', 'E', 'Kepala Bagian', 'FathurFirmansyah@gmail.com', '1997-10-11', 'none'),
('E2', 'Sugiono', 'E', 'Bagian', 'Sugiono@gmail.com', '1998-08-19', 'none'),
('FO001', 'Lisa Aprilia', 'FO', 'Kepala Bagian', 'LisaAprilia@gmail.com', '1996-10-15', 'none'),
('HK001', 'Deni Sugianto', 'HK', 'Kepala Bagian', 'DeniSugiarto@gmail.com', '1995-10-15', 'none'),
('ITO001', 'Sani Hidayat', 'ITO', 'Kepala Bagian', 'SaniHidayat@gmail.com', '1996-10-14', 'none'),
('KTC1', 'TIO', 'KTC', 'Kepala Bagian', 'tio@gmail.com', '1989-10-12', 'none'),
('O1', 'Irwansyah', 'O', 'Kepala Bagian', 'Irwansyah@gmail.com', '1996-12-18', 'none');

-- --------------------------------------------------------

--
-- Struktur dari tabel `peralatan`
--

CREATE TABLE `peralatan` (
  `kode_peralatan` int(10) NOT NULL,
  `nama_peralatan` varchar(25) NOT NULL,
  `jenis_peralatan` varchar(20) NOT NULL,
  `keterangan` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `peralatan`
--

INSERT INTO `peralatan` (`kode_peralatan`, `nama_peralatan`, `jenis_peralatan`, `keterangan`) VALUES
(1, 'Televisi', 'Elektronik', 'kondisi masih baik'),
(2, 'kompor', 'Elektronik', 'masih bagus'),
(3, 'Kulkas', 'Elektronik', 'Masih Baru'),
(4, 'AC', 'Elektronik', 'Masih Mulus'),
(5, 'Meja', 'Bukan Elektronik', 'Masih Mulus'),
(6, 'Kasur', 'Bukan Elektronik', 'Jumlah Total 20');

-- --------------------------------------------------------

--
-- Struktur dari tabel `perbaikan`
--

CREATE TABLE `perbaikan` (
  `kode_perbaikan` int(10) NOT NULL,
  `tanggal_perbaikan` datetime DEFAULT NULL,
  `keterangan` text,
  `status` varchar(15) NOT NULL,
  `kode_peralatan` int(10) NOT NULL,
  `nip` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `permasalahan`
--

CREATE TABLE `permasalahan` (
  `kode_permasalahan` int(10) NOT NULL,
  `tanggal_permasalahan` datetime DEFAULT NULL,
  `keterangan` text,
  `status` varchar(15) NOT NULL,
  `nip` varchar(8) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `permasalahan`
--

INSERT INTO `permasalahan` (`kode_permasalahan`, `tanggal_permasalahan`, `keterangan`, `status`, `nip`) VALUES
(1, '2019-10-24 00:00:00', 'Komputer P10 rusak', 'Dibuat', 'O1');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `nip` varchar(8) NOT NULL,
  `username` varchar(32) NOT NULL,
  `password` varchar(32) NOT NULL,
  `hak_akses` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`nip`, `username`, `password`, `hak_akses`) VALUES
('FO001', 'LisaAprilia@gmail.com', '19961015', 'FO'),
('HK001', 'DeniSugiarto@gmail.com', '19951015', 'HK'),
('ITO001', 'SaniHidayat@gmail.com', '19961014', 'ITO'),
('O1', 'Irwansyah@gmail.com', '19961218', 'O'),
('E1', 'FathurFirmansyah@gmail.com', '19971011', 'E'),
('KTC1', 'tio@gmail.com', '19891012', 'KTC');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `departement`
--
ALTER TABLE `departement`
  ADD PRIMARY KEY (`kode_departement`);

--
-- Indexes for table `pegawai`
--
ALTER TABLE `pegawai`
  ADD PRIMARY KEY (`nip`),
  ADD KEY `kode_departement` (`kode_departement`);

--
-- Indexes for table `peralatan`
--
ALTER TABLE `peralatan`
  ADD PRIMARY KEY (`kode_peralatan`);

--
-- Indexes for table `perbaikan`
--
ALTER TABLE `perbaikan`
  ADD PRIMARY KEY (`kode_perbaikan`),
  ADD KEY `kode_peralatan` (`kode_peralatan`),
  ADD KEY `nip` (`nip`);

--
-- Indexes for table `permasalahan`
--
ALTER TABLE `permasalahan`
  ADD PRIMARY KEY (`kode_permasalahan`),
  ADD KEY `nip` (`nip`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD KEY `nip` (`nip`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `peralatan`
--
ALTER TABLE `peralatan`
  MODIFY `kode_peralatan` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `perbaikan`
--
ALTER TABLE `perbaikan`
  MODIFY `kode_perbaikan` int(10) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `permasalahan`
--
ALTER TABLE `permasalahan`
  MODIFY `kode_permasalahan` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- Ketidakleluasaan untuk tabel pelimpahan (Dumped Tables)
--

--
-- Ketidakleluasaan untuk tabel `pegawai`
--
ALTER TABLE `pegawai`
  ADD CONSTRAINT `pegawai_ibfk_1` FOREIGN KEY (`kode_departement`) REFERENCES `departement` (`kode_departement`);

--
-- Ketidakleluasaan untuk tabel `perbaikan`
--
ALTER TABLE `perbaikan`
  ADD CONSTRAINT `perbaikan_ibfk_1` FOREIGN KEY (`kode_peralatan`) REFERENCES `peralatan` (`kode_peralatan`),
  ADD CONSTRAINT `perbaikan_ibfk_2` FOREIGN KEY (`nip`) REFERENCES `pegawai` (`nip`);

--
-- Ketidakleluasaan untuk tabel `permasalahan`
--
ALTER TABLE `permasalahan`
  ADD CONSTRAINT `permasalahan_ibfk_1` FOREIGN KEY (`nip`) REFERENCES `pegawai` (`nip`);

--
-- Ketidakleluasaan untuk tabel `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `user_ibfk_1` FOREIGN KEY (`nip`) REFERENCES `pegawai` (`nip`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
