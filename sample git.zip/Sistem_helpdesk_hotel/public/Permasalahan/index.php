<?php
$permasalahan = new \model\Permasalahan();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title><?php echo APP_NAME; ?>Permasalahan</title>

    <?php inc("include/includeCSS") ?>

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div id="wrapper">

        <!-- Navigation -->
        <?php inc("include/navigation") 

        ?>

        <div id="page-wrapper">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="page-header">Permasalahan</h1>
                </div>
                <!-- /.col-lg-12 -->
            </div>
            
            <?php 
                $request = new \engine\http\Request;
                $notifikasi = $request->getNotification();
                
                if($notifikasi != ''){
            ?>
                <br><div class="alert alert-succes alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
                    <?php echo $notifikasi; ?> 
                </div><br>
            <?php } ?>


            <div class="panel-body">
            <a class="btn btn-primary" href="<?php url("Permasalahan/add/") ?>">Tambah</a><br><br>
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th>Kode Permasalahan</th>
                                            <th>Tanggal Permasalahan</th>
                                            <th>Keterangan</th>
                                            <th>status</th>
                                            <th>Nip</th>
                                            <th>Kode Departement</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    <?php 
                                    $hak_akses = $_SESSION['hak_akses'];

                                    $permasalahan->select($permasalahan->getTable())->ready();
                                
                                    while($row = $permasalahan->getStatement()->fetch()){ ?>
                                        <tr>
                                            <td><?php echo $row['kode_permasalahan']?></td>
                                            <td><?php echo $row['tanggal_permasalahan']?></td>
                                            <td><?php echo $row['keterangan']?></td>
                                            <td><?php echo $row['status']?></td>
                                            <td><?php echo $row['nip']?></td>
                                            <td><?php echo $row['kode_departement']?></td>
                                            <?php if($hak_akses == 'O' || $hak_akses == 'ITO'){ ?>
                                                <!--<td><a class="btn btn-primary" href="<?php //url("Permasalahan/perbarui/".$row[0]."/")?>">Lihat</a></td>-->
                                                    <td>
                                                        <button class="btn btn-danger" data-toggle="modal" data-target="#myModal">
                                                            hapus
                                                        </button>
                                                    </td>
                                            <?php } ?>
                                        </tr>
                                <?php   }
                                ?>
                                    </tbody>
                                </table>
                            </div>
                            <!-- /.table-responsive -->
                        </div>
           
        </div>
        <!-- /#page-wrapper -->

    <!-- Modal -->
        <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                        <h4 class="modal-title" id="myModalLabel">Permasalahan</h4>
                    </div>
                    <div class="modal-body">
                        Apakah anda ingin menghapus data
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
                        <button type="button" class="btn btn-primary">Save changes</button>
                    </div>
                </div>
                <!-- /.modal-content -->
            </div>
            <!-- /.modal-dialog -->
        </div>

    </div>
    <!-- /#wrapper -->

    <?php inc("include/includeJS") ?>
    <script>
    $("document").ready(function(){

    });
    </script>
</body>

</html>
