
    <!-- Bootstrap Core CSS -->
    <link href="<?php asset('vendor/bootstrap/css/bootstrap.min.css') ?>" rel="stylesheet">

    <!-- MetisMenu CSS -->
    <link href="<?php asset('vendor/metisMenu/metisMenu.min.css') ?>" rel="stylesheet">

    <!-- DataTables CSS -->
    <link href="<?php asset('vendor/datatables-plugins/dataTables.bootstrap.css') ?>" rel="stylesheet">

    <!-- DataTables Responsive CSS -->
    <link href="<?php asset('vendor/datatables-responsive/dataTables.responsive.css') ?>" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="<?php asset('dist/css/sb-admin-2.css') ?>" rel="stylesheet">

    <!-- Custom Fonts -->
    <link href="<?php asset('vendor/font-awesome/css/font-awesome.min.css') ?>" rel="stylesheet" type="text/css">

