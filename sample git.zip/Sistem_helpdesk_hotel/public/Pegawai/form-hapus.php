<?php $request = new \engine\http\Request(); ?>
<html>
<head>
    <title><?php echo APP_NAME ?>Pegawai</title>

    <?php inc("include/includeCSS") ?>
</head>
<body>
    <div class="" tabindex="-1">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title" id="myModalLabel">Pegawai</h4>
                </div>
                <div class="modal-body">
                    Apakah anda yakin menghapus data pegawai dengan nip <?php echo $request->get(2) ?>
                </div>
                <div class="modal-footer">
                    <a href="<?php url('Pegawai/') ?>" class="btn btn-default">Tutup</a>
                    <a href="<?php url('HapusPegawai/') ?>" class="btn btn-primary">Simpan Perubahan</a>
                </div>
            </div>
            <!-- /.modal-content -->
        </div>
        <!-- /.modal-dialog -->
    </div>    
</body>
</html>

